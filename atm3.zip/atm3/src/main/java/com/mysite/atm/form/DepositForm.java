package com.mysite.atm.form;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepositForm {
	
    //@NotNull(message = "口座番号入力は必須項目です。")
    //@Positive(message = "口座番号は正数で入力しなければなりません。")
    //@Digits(integer = 7, fraction = 0, message = "口座番号は7桁で入力してください。")
	//private Integer accountNumber;
	
    @NotNull(message = "入金金額の入力は必須項目です。")
    @Positive(message = "入金金額は正数で入力しなければなりません。")
	private Integer amount;
	
}