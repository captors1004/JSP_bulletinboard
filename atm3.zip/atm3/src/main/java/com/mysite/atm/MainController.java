package com.mysite.atm;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {

    @GetMapping("/atm3")
    @ResponseBody
    public String index() {
        return "ようこそ ATM3";
    }

    @GetMapping("/")
    public String root() {
        return "redirect:/atm3";
    }
    
    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";
    }
}