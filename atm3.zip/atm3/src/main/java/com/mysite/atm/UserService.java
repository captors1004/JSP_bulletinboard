package com.mysite.atm;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UserService {

    private final UsersRepository usersRepository;
    private final AccountRepository accountRepository;
    private final PasswordEncoder passwordEncoder;
    
	    public Users create(String username, String email, String password) {
	        Users users = new Users();
	        users.setUsername(username);
	        users.setEmail(email);
	        users.setPassword(passwordEncoder.encode(password));
	        users.setCreateDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
	        users.setLoginStatus(false);
	        this.usersRepository.save(users);
	
	        return users;
	        }
	
	    public Users getUsers(String username) {
	    	Optional<Users> users = this.usersRepository.findByusername(username);
	    	if(users.isPresent()) {
	    		return users.get();
	    	} else {
	    		throw new DataNotFoundException("users not found");
	    	}
	    }
}