package com.mysite.atm;

import com.mysite.atm.form.TransactionType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class TransactionA {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	// 1 = お引き出し
	// 2 = お預入れ
	// 3 = お振込み
	@Column
    @Enumerated(EnumType.STRING)
	private TransactionType transactionType;
	
	@Column(length=10)
	private Integer transactionAmount;

    @Column
    private Integer accountNumber;
 
    @Column
    private Integer senderAccountNumber;

    @Column
    private Integer receiverAccountNumber;
    
	@Column(length=10)
	private Integer accountBefore;

	@Column(length=10)
	private Integer accountAfter;
	
	@Column
	private String transactionDate;

	//口座番号 account_number
	@ManyToOne
	private Account account;
	
	@ManyToOne
	private Users users;
}