package com.mysite.atm.form;

public enum TransactionType {
	口座開設,
    お預入れ,
    引き出し,
    振り込み
}