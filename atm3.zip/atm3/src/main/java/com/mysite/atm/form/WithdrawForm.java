package com.mysite.atm.form;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WithdrawForm {

    //@NotNull(message = "口座番号入力は必須項目です。")
    //@Positive(message = "口座番号は数で入力しなければなりません。")
    //@Digits(integer = 7, fraction = 0, message = "口座番号は7桁で入力してください。")
	//private Integer accountNumber;
	
    @NotNull(message = "出金金額の入力は必須項目です。")
    @Positive(message = "出金金額は正数で入力しなければなりません。")
	private Integer amount;
    
}
