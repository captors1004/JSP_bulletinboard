package com.mysite.atm;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

    @Column(unique = true)
	private Integer accountNumber;
	
	@ManyToOne
	private Users users;
	
	@Column(length = 4)
	private Integer accountPIN;
	
	@Column(precision = 10, scale = 2)
	private Integer accountBalance;
	
	@Column(precision = 10, scale = 2)
	private Integer amount;
	
	@OneToMany(mappedBy ="account", cascade = CascadeType.REMOVE)
	private List<TransactionA> transactionAList;
	
}
