package com.mysite.atm;

import java.security.Principal;
import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mysite.atm.form.DepositForm;
import com.mysite.atm.form.RemitForm;
import com.mysite.atm.form.TransactionType;
import com.mysite.atm.form.WithdrawForm;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping("/dashboard")
public class AccountController {
	
	private final AccountService accountService;
	private final TransactionAService transactionAService;
	private final UserService userService;
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/account/list")
    public String list(Model model) {
    	List<Account> accountAll = this.accountService.getList();
    	model.addAttribute("accountAll", accountAll);
        return "account_list";
    }
    
    //deposit*****************************/
    //
    //
    @PreAuthorize("isAuthenticated()")
	@GetMapping("/deposit")
	public String depositDo(Model model, DepositForm depositForm, Principal principal) {
		
    	Users users = this.userService.getUsers(principal.getName());
    	List<Account> accountList = users.getAccountList();
    	model.addAttribute("accountList", accountList);
    	return "deposit_form";	
	}

    @PreAuthorize("isAuthenticated()")
	@PostMapping("/deposit/depositDo")
	public String depositDo(Model model, @Valid DepositForm depositForm, BindingResult bindingResult, Principal principal){
		if(bindingResult.hasErrors()) {
			return "deposit_form";
		}
		Users users = this.userService.getUsers(principal.getName());
    	List<Account> accountList = users.getAccountList();
    	
    	if(accountList.size()!=1) {
    		bindingResult.reject("depositFail", "口座番号が複数です。");
    		return "deposit_form";
    	}
    	
		Account account = this.accountService.getAccount(accountList.get(0).getAccountNumber());
		//登録された口座がない場合
		if(account == null) {
			bindingResult.reject("depositFail", "同録されてない口座番号です。");
			return "deposit_form";
		}
		
		Integer currentBalance = account.getAccountBalance();
		this.accountService.deposit(account.getAccountNumber(), depositForm.getAmount() /*,users*/);
		Integer newBalance = account.getAccountBalance();
		// 0 = 口座生成
		// 1 = お引き出し(deposit)
		// 2 = お預入れ
		// 3 = お振込み
		transactionAService.saveTransaction(TransactionType.お預入れ, account.getAccountNumber(), depositForm.getAmount(), currentBalance, newBalance, account, null, null);
		//transactionAService.saveTransaction(1, account.getAccountNumber(), account.getAmount(), account);
    	model.addAttribute("account", account);
		return "deposit_result"; //お預入れした後、入金完了画面へ移動
	}
    
    
    //withdraw*****************************/
    //
    //
    @PreAuthorize("isAuthenticated()")
	@GetMapping("/withdraw")
	public String withdraw(Model model, WithdrawForm withdrawForm, Principal principal) {
    	Users users = this.userService.getUsers(principal.getName());
    	List<Account> accountList = users.getAccountList();
    	model.addAttribute("accountList", accountList);
		return "withdraw_form";	
	}
    
    
    @PreAuthorize("isAuthenticated()")
	@PostMapping("/withdraw/withdrawDo")
	public String withdrawDo(Model model, @Valid WithdrawForm withdrawForm, BindingResult bindingResult, Principal principal){
		if(bindingResult.hasErrors()) {
			return "withdraw_form";
		}
		
		Users users = this.userService.getUsers(principal.getName());
    	List<Account> accountList = users.getAccountList();
    	
    	//口座番号が複数が確認
    	if(accountList.size()!=1) {
    		bindingResult.reject("withdrawFail", "口座番号が複数です。");
    		return "withdraw_form";
    	}
    	
		Account account = this.accountService.getAccount(accountList.get(0).getAccountNumber());
		
		//登録された口座がない場合
		if(account == null) {
			bindingResult.reject("withdrawFail", "同録されてない口座番号です。");
			return "withdraw_form";
		}
		
		Integer currentBalance = account.getAccountBalance();
		this.accountService.withdraw(account.getAccountNumber(), withdrawForm.getAmount()/*,users*/);
		Integer newBalance = account.getAccountBalance();
		
		// 2 = お預入れ (withdraw)
		//transactionAService.saveTransaction(2, withdrawForm.getAccountNumber(), -(withdrawForm.getAmount()));
		transactionAService.saveTransaction(TransactionType.引き出し, account.getAccountNumber(), -(withdrawForm.getAmount()), currentBalance, newBalance, account, null, null);
    	model.addAttribute("account", account);
		return "withdraw_result"; //お預入れした後、入金完了画面へ移動
	}
    
    //remit*****************************/
    //
    //
    @PreAuthorize("isAuthenticated()")
	@GetMapping("/remit")
	public String remit(Model model, RemitForm remitForm, Principal principal) {
    	Users users = this.userService.getUsers(principal.getName());
    	List<Account> accountList = users.getAccountList();
    	model.addAttribute("accountList", accountList);
		return "remit_form";
	}
    
    
    @PreAuthorize("isAuthenticated()")
	@PostMapping("/remit/remitDo")
	public String remitDo(Model model, @Valid RemitForm remitForm, BindingResult bindingResult, Principal principal){
		if(bindingResult.hasErrors()) {
			return "remit_form";
		}
		
		Users users = this.userService.getUsers(principal.getName());
    	List<Account> accountList = users.getAccountList();
    	
    	//口座番号が複数が確認
    	if(accountList.size()!=1) {
    		bindingResult.reject("remitFail", "口座番号が複数です。");
    		return "remit_form";
    	}
		
		//現在ユーザーの引き出し口座番号が存在確認
		Account senderAccount =this.accountService.getAccount(accountList.get(0).getAccountNumber());
			if(senderAccount == null) {
	        	bindingResult.reject("remitFail", "引き出し口座番号が同録されてない口座番号です。");
				return "remit_form";
			}
			
			
		//送金先の口座番号が存在確認
		Account receiverAccount =this.accountService.getAccount(remitForm.getReceiverAccountNumber());
			if(receiverAccount == null) {
				bindingResult.reject("remitFail", "送金先の口座番号が同録されてない口座番号です。");
				return "remit_form";
			}
		//現在loginしたユーザーや送金先の口座番号が同じの場合
			if(senderAccount.getAccountNumber() == receiverAccount.getAccountNumber() ) {
				bindingResult.reject("remitFail", "現在loginしたユーザーや送金先の口座番号が同じ口座番号です。");
				return "remit_form";
			}
			
			
		Integer senderCurrentBalance = senderAccount.getAccountBalance();
		Integer receiverCurrentBalance = receiverAccount.getAccountBalance();
		
		this.accountService.remit(senderAccount.getAccountNumber(), remitForm.getReceiverAccountNumber(), remitForm.getAmount()/*,users*/);
		
		Integer senderNewBalance = senderAccount.getAccountBalance();
		Integer receiverNewBalance = receiverAccount.getAccountBalance();
		
		transactionAService.saveTransaction(TransactionType.振り込み, senderAccount.getAccountNumber(), -(remitForm.getAmount()), senderCurrentBalance, senderNewBalance, senderAccount, null, remitForm.getReceiverAccountNumber());
		transactionAService.saveTransaction(TransactionType.振り込み, remitForm.getReceiverAccountNumber(), remitForm.getAmount(), receiverCurrentBalance, receiverNewBalance, receiverAccount, senderAccount.getAccountNumber(), null);
		
		model.addAttribute("senderAccount", senderAccount);
		model.addAttribute("receiverAccount", receiverAccount);
		return "remit_result"; //振込した後、入金完了画面へ移動
	}
}