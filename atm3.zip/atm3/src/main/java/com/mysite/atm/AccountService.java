package com.mysite.atm;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class AccountService {
		
	private final AccountRepository accountRepository;
    private final UserService userService;
    
    //口座同録
	public Account create(Users users) {
		Account account = new Account();
		account.setAccountNumber(generateAccountNumber());
		account.setUsers(users);
		account.setAccountPIN(0000);
		account.setAccountBalance(00);
		this.accountRepository.save(account);
		
		return account;
	}

	    private Integer generateAccountNumber() {
			Random random = new Random();
			int min = 1000000;
			int max = 9999999;
			return random.nextInt(max - min + 1) + min;
	    }
    
    public List<Account> getList(){
    	return this.accountRepository.findAll();
    }

    //계좌번호로 계좌찾기
    public Account getAccount(Integer accountNumber){
    	Optional<Account> account = this.accountRepository.findByAccountNumber(accountNumber);
    	if(account.isPresent()) {
    		return account.get();
    	}else {
            return null;
    		//throw new DataNotFoundException("accountNumber not found");
    	}
    }
 
    //입금하기
    public Account deposit(Integer accountNumber, Integer amount) {
		Account account = new Account();
		account = getAccount(accountNumber);

        Integer currentBalance = account.getAccountBalance();
        Integer newBalance = currentBalance + amount;
    	account.setAccountBalance(newBalance);
    	account.setAmount(amount);
    	//account.setUsers(users);
    	this.accountRepository.save(account);
    	return account;
    }
    
    //출금하기
    public Account withdraw(Integer accountNumber, Integer amount) {
    	Account account = new Account();
    	account = getAccount(accountNumber);
    	
    	Integer currentBalance = account.getAccountBalance();
    	Integer newBalance = currentBalance - amount;
    	account.setAccountBalance(newBalance);
    	
    	account.setAmount(amount);
    	//account.setUsers(users);
    	this.accountRepository.save(account);
    	return account;
    }

    public boolean remit(Integer senderAccountNumber, Integer receiverAccountNumber, Integer amount) {
    	Account senderAccount = new Account();
    	Account receiverAccount = new Account();

    	senderAccount = getAccount(senderAccountNumber);
    	receiverAccount = getAccount(receiverAccountNumber);
    	//口座残高
    	Integer senderBalance = senderAccount.getAccountBalance();
    	Integer receiverBalance = receiverAccount.getAccountBalance();
    	
    	if(senderBalance >= amount) {
    		// 돈을 밴다
    		senderBalance  -= amount;
            // 송금받는 계좌에 돈을 입금합니다.
            receiverBalance += amount;
    		
    		senderAccount.setAccountBalance(senderBalance);
    		senderAccount.setAmount(amount);
    		this.accountRepository.save(senderAccount);
    		receiverAccount.setAccountBalance(receiverBalance);
    		receiverAccount.setAmount(amount);
    		this.accountRepository.save(receiverAccount);
    		
    	} else {
            throw new IllegalArgumentException("残高不足して振り込みができます。");
    	}
    	return true;
    }
}