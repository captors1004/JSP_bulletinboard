package com.mysite.atm;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account, Integer>{

	Optional<Account> findByAccountNumber(Integer accountNumber);
	Account findByUsers(Users users);
	//	Optional<Account> findByUsers(Users users);
}