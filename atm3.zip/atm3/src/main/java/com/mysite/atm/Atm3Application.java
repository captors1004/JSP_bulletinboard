package com.mysite.atm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atm3Application {

	public static void main(String[] args) {
		SpringApplication.run(Atm3Application.class, args);
	}
}