package com.mysite.atm;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.mysite.atm.form.TransactionType;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class TransactionAService {

	private final TransactionRepository transactionRepository;

    

    public Page<TransactionA> getList(Integer accountNumber, int page){
    	List<Sort.Order> sorts = new ArrayList<>();
    	sorts.add(Sort.Order.desc("transactionDate"));
    	Pageable pageable = PageRequest.of(page, 10, Sort.by(sorts));
    	return this.transactionRepository.findTransactionAByAccountNumber(accountNumber, pageable);
    }

	//「口座番号」で取引履歴をちょうかい照会する
	public TransactionA getTransactionA(Integer accountNumber) {
    	Optional<TransactionA> transactionAList = this.transactionRepository.findByAccountNumber(accountNumber);
    	
    	if(transactionAList.isPresent()) {
    		return transactionAList.get();
    	} else {
    		return null;
    		//throw new DataNotFoundException("transaction not found in this accountNumber");
    	}
	}
	
	//口座を初めて作る時に使うmethod
	public void createTransaction(Users users, Account account) {
		TransactionA transactionA = new TransactionA();
		transactionA.setUsers(users);
		transactionA.setAccount(account);
		transactionA.setAccountNumber(account.getAccountNumber());
		transactionA.setTransactionType(TransactionType.口座開設);
		transactionA.setTransactionDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		transactionRepository.save(transactionA);
	}

	//口座番号で取引履歴を作成めとるmethod
	public void saveTransaction(TransactionType transactionType, Integer accountNumber, Integer transactionAmount,
			Integer accountBefore, Integer accountAfter, Account account, Integer senderAccountNumber, Integer receiverAccountNumber) {

		TransactionA transactionA = new TransactionA();
		transactionA.setTransactionType(transactionType);
		transactionA.setAccountNumber(accountNumber);
		transactionA.setTransactionAmount(transactionAmount);
		transactionA.setAccountBefore(accountBefore);
		transactionA.setAccountAfter(accountAfter);
		transactionA.setAccount(account);
		transactionA.setSenderAccountNumber(senderAccountNumber);
		transactionA.setReceiverAccountNumber(receiverAccountNumber);
		transactionA.setTransactionDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		transactionRepository.save(transactionA);
		//transactionA.set
	}
	
	public void transferTransaction(TransactionType transactionType, Integer accountNumber, Integer transactionAmount) {
		TransactionA transactionA = new TransactionA();
		transactionA.setTransactionType(transactionType);
		transactionA.setAccountNumber(accountNumber);
		transactionA.setTransactionAmount(transactionAmount);
		transactionA.setTransactionDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		transactionRepository.save(transactionA);
		//transactionA.set
	}
}