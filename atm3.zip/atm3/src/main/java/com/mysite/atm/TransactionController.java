package com.mysite.atm;
import java.security.Principal;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysite.atm.form.TransactionAForm;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping("/dashboard")
public class TransactionController {
	
	private final AccountService accountService;
	private final TransactionAService transactionAService;
	private final UserService userService;

	@PreAuthorize("isAuthenticated()")
	@GetMapping("/transaction/loginAccount")
    public String loginAccountInform(Model model, @RequestParam(value="page", defaultValue="0") int page, Principal principal) {
		Users users = this.userService.getUsers(principal.getName());
    	List<Account> accountList = users.getAccountList();
    	
		Account account = this.accountService.getAccount(accountList.get(0).getAccountNumber());
		Page<TransactionA> paging = this.transactionAService.getList(account.getAccountNumber(), page);
		model.addAttribute("paging", paging);
		return "loginAccount_inform";
    }
	
	
    @PreAuthorize("isAuthenticated()")
	@GetMapping("/transaction/inputForm")
	public String transactionAList(Model model, TransactionAForm transactionAForm) {
		return "transactionList_form";
	}

    @PreAuthorize("isAuthenticated()")
	@GetMapping("/transaction/list")
	public String transactionListResult(Model model, @RequestParam(value="page", defaultValue="0") int page, @Valid TransactionAForm transactionAForm, BindingResult bindingResult, Principal principal) {
		if(bindingResult.hasErrors()) {
			return "transactionList_form";
		}
    	//List<Account> accountAll = this.accountService.getList();
		//계좌 존재하는지 조회하기
		//Users users = this.userService.getUsers(principal.getName());
		Account account = this.accountService.getAccount(transactionAForm.getAccountNumber());
		if(account == null) {
			bindingResult.reject("transactionFail", "同録されてない口座番号です。");
			return "transactionList_form";
		}
		//List<TransactionA> transactionAList = transactionA.getAccountNumber();
		//登録された口座がない場合
		
        List<TransactionA> transactionAList = account.getTransactionAList();
        if(transactionAList == null) {
			bindingResult.reject("transactionFail", "取引履歴がないです。");
			return "transactionList_form";
		}
		
		Page<TransactionA> paging = this.transactionAService.getList(transactionAForm.getAccountNumber(), page);
		model.addAttribute("paging", paging);
		//model.addAttribute("transactionAList", transactionAList);
		return "transactionList";
		
	}
}