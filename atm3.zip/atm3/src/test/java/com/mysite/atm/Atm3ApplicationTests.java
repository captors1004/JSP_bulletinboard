package com.mysite.atm;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atm3ApplicationTests {
	
	@Autowired
	private UsersRepository usersRepository;
	
	@Test
	void testJpa() {
		Users u1 = new Users();
		u1.setUsername("nameaaa");
		u1.setEmail("a@a.com");
		u1.setPassword("aaa");
		u1.setLoginStatus(false);
		//u1.setCreateDate(LocalDateTime.now());
        this.usersRepository.save(u1);  // 1번째 user 저장		

        
        Users u2 = new Users();
        u2.setUsername("namebbb");
        u2.setEmail("b@b.com");
        u2.setPassword("bbb");
        u2.setLoginStatus(false);
        //u2.setCreateDate(LocalDateTime.now());
        this.usersRepository.save(u2);  // 2번째 user 저장		
	}

}
